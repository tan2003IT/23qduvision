#ifndef GETIMG_H
#define GETIMG_H
#include"opencv2/opencv.hpp"
#include"qdatetime.h"
cv::Mat compress(cv::Mat img[]);
void getimg();
#endif // GETIMG_H
