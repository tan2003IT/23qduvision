#ifndef CHECK_H
#define CHECK_H

#include <QMessageBox>

void check_img_Null();

bool check_img_save();

#endif // CHECK_H
